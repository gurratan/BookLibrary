package com.termproject;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class CrudActions {

	List<BookLbry> insertRecord = new ArrayList<BookLbry>();
	String filename = "file.ser";

	@SuppressWarnings("unchecked")
	public void insertRecord(String bookId, String bookname, String authorName, String category, String publisher,
			int price) {
		FileInputStream fout1;
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			empList.add(new BookLbry(bookId, bookname, authorName, category, publisher, price));
			FileOutputStream file = new FileOutputStream(filename);
			ObjectOutputStream out = new ObjectOutputStream(file);

			// Method for serialization of object

			out.writeObject(empList);
			oin.close();
			out.close();
			file.close();

			System.out.println("Object has been serialized");
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public void addRecordtoFile() {
		try {
			// Saving of object in a file
			FileOutputStream file = new FileOutputStream(filename);
			ObjectOutputStream out = new ObjectOutputStream(file);

			// Method for serialization of object

			out.writeObject(insertRecord);

			out.close();
			file.close();

			System.out.println("Object has been serialized");

		}

		catch (IOException ex) {
			ex.printStackTrace();
			System.out.println("IOException is caught");
		}
	}
	@SuppressWarnings("unchecked")
	public void displayRecord() {
		FileInputStream fout1;
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			for (int i = 0; i < empList.size(); i++) {

				System.out.println(empList.get(i));

			}
			oin.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}
	@SuppressWarnings("unchecked")
	public void displayRecordByBookName(String bookname) {
		FileInputStream fout1;
		System.out.println("");
		System.out.println("+++++++++++++++++++++++++++");
		System.out.println(" Searched by Book Name :");
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			for (int i = 0; i < empList.size(); i++) {
				if (empList.get(i).getBookname().equalsIgnoreCase(bookname)) {
					System.out.println(empList.get(i));
				}

			}
			oin.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void displayRecordByBookID(String bookID) {
		FileInputStream fout1;
		System.out.println("");
		System.out.println("+++++++++++++++++++++++++++");
		System.out.println(" Searched by Book ID :");
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			for (int i = 0; i < empList.size(); i++) {
				if (empList.get(i).getBookId().equalsIgnoreCase(bookID)) {
					System.out.println(empList.get(i));
				}

			}
			oin.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void displayRecordByAuthorName(String Authorname) {
		FileInputStream fout1;
		System.out.println("");
		System.out.println("+++++++++++++++++++++++++++");
		System.out.println(" Searched by Author Name :");
		
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			for (int i = 0; i < empList.size(); i++) {
				if (empList.get(i).getAuthorName().equalsIgnoreCase(Authorname)) {
					System.out.println(empList.get(i));
				}

			}oin.close();
			

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void sortByBookName() {
		FileInputStream fout1;
		System.out.println("");
		System.out.println("+++++++++++++++++++++++++++");
		System.out.println(" sorted  by Book Name :");
		
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			
			Collections.sort(empList, new Comparator<BookLbry>() {
				

				@Override
				public int compare(BookLbry o1, BookLbry o2) {
					// TODO Auto-generated method stub
					return o1.getBookname().compareTo(o2.getBookname()) ;
				}
			});
			
			for (int i = 0; i < empList.size(); i++) {
				
					System.out.println(empList.get(i));
				

			}oin.close();
			

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void sortByAuthor() {
		FileInputStream fout1;
		System.out.println("");
		System.out.println("+++++++++++++++++++++++++++");
		System.out.println(" sorted  by Author Name :");
		
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			
			Collections.sort(empList, new Comparator<BookLbry>() {
				

				@Override
				public int compare(BookLbry o1, BookLbry o2) {
					// TODO Auto-generated method stub
					return o1.getAuthorName().compareTo(o2.getAuthorName()) ;
				}
			});
			
			for (int i = 0; i < empList.size(); i++) {
				
					System.out.println(empList.get(i));
				

			}
			oin.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	public void sortByprice() {
		FileInputStream fout1;
		System.out.println("");
		System.out.println("+++++++++++++++++++++++++++");
		System.out.println(" sorted  by Price :");
		
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			
			Collections.sort(empList, new Comparator<BookLbry>() {
				

				@Override
				public int compare(BookLbry o1, BookLbry o2) {
					// TODO Auto-generated method stub
					return o1.getPrice()-o2.getPrice();
				}
			});
			
			for (int i = 0; i < empList.size(); i++) {
				
					System.out.println(empList.get(i));
				

			}
			
			oin.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	@SuppressWarnings("unchecked")
	public void updateRecord(String bookID, String bookName, String AuthorName,String catagory, String publisher,int price) {
		FileInputStream fout1;
		System.out.println("");
		System.out.println("+++++++++++++++++++++++++++");
		System.out.println(" Record updated for the given BOok ID :");
		
		try {
			fout1 = new FileInputStream("file.ser");

			ObjectInputStream oin = new ObjectInputStream(fout1);
			List<BookLbry> empList = new ArrayList<BookLbry>();
			empList = (List<BookLbry>) oin.readObject();
			for (int i = 0; i < empList.size(); i++) {
				if (empList.get(i).getBookId().equalsIgnoreCase(bookID)) {
					empList.get(i).setAuthorName(AuthorName);
					empList.get(i).setBookname(bookName);
					empList.get(i).setPublisher(publisher);
					empList.get(i).setPrice(price);
					empList.get(i).setCategory(catagory);
				}

			}
			FileOutputStream file = new FileOutputStream(filename);
			ObjectOutputStream out = new ObjectOutputStream(file);

			// Method for serialization of object

			out.writeObject(empList);
			oin.close();
			out.close();
			file.close();
			
			

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
