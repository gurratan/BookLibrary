package com.termproject;

import java.io.Serializable;

@SuppressWarnings("serial")
public class BookLbry implements Serializable {
private String bookId;
private String bookname;
private String authorName;
private String category;
private String publisher;
private int price;
public BookLbry(String bookId, String bookname, String authorName, String category, String publisher, int price) {
	super();
	this.bookId = bookId;
	this.bookname = bookname;
	this.authorName = authorName;
	this.category = category;
	this.publisher = publisher;
	this.price = price;
}

public String getBookId() {
	return bookId;
}
public void setBookId(String bookId) {
	this.bookId = bookId;
}
public String getBookname() {
	return bookname;
}
public void setBookname(String bookname) {
	this.bookname = bookname;
}
public String getAuthorName() {
	return authorName;
}
public void setAuthorName(String authorName) {
	this.authorName = authorName;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getPublisher() {
	return publisher;
}
public void setPublisher(String publisher) {
	this.publisher = publisher;
}
public int getPrice() {
	return price;
}
public void setPrice(int price) {
	this.price = price;
}
@Override
public String toString() { 
    return String.format("Book ID :" +bookId+"\n Book Name :"+bookname +"\n Author Name "+authorName +" \n Category : "+category +"\n Publisher :" +publisher +"\n Price: "+price ); 
} 


}
