package com.termproject;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import javax.swing.JScrollPane;
import javax.swing.JTextField;


import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import java.io.PrintStream;

import javax.swing.JTextArea;

import javax.swing.ScrollPaneConstants;

@SuppressWarnings("serial")
public class Driver extends JFrame{

	private JFrame frame;
	private JTextField txtBookId;
	private JTextField txt_BookName;
	private JTextField txtAuthorName;
	private JTextField txt_category;
	private JTextField txt_Publisher;
	private JTextField txt_Price;
	JTextArea ta = new JTextArea();
	JTextArea textArea = new JTextArea();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Driver window = new Driver();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Driver() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 512, 435);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
	
	  

		
		
		CrudActions ac = new CrudActions();
		JLabel lblNewLabel = new JLabel("BookID");
		lblNewLabel.setBounds(6, 6, 61, 16);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Book Name");
		lblNewLabel_1.setBounds(6, 31, 108, 16);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Author Name");
		lblNewLabel_2.setBounds(6, 54, 108, 16);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Category");
		lblNewLabel_3.setBounds(6, 82, 61, 16);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Publisher ");
		lblNewLabel_4.setBounds(6, 116, 94, 16);
		frame.getContentPane().add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Price");
		lblNewLabel_5.setBounds(6, 144, 61, 16);
		frame.getContentPane().add(lblNewLabel_5);
		
		txtBookId = new JTextField();
		txtBookId.setBounds(148, 1, 130, 26);
		frame.getContentPane().add(txtBookId);
		txtBookId.setColumns(10);
		
		txt_BookName = new JTextField();
		txt_BookName.setBounds(148, 26, 130, 26);
		frame.getContentPane().add(txt_BookName);
		txt_BookName.setColumns(10);
		
		txtAuthorName = new JTextField();
		txtAuthorName.setBounds(148, 52, 130, 26);
		frame.getContentPane().add(txtAuthorName);
		txtAuthorName.setColumns(10);
		
		txt_category = new JTextField();
		txt_category.setBounds(148, 77, 130, 26);
		frame.getContentPane().add(txt_category);
		txt_category.setColumns(10);
		
		txt_Publisher = new JTextField();
		txt_Publisher.setBounds(148, 109, 130, 26);
		frame.getContentPane().add(txt_Publisher);
		txt_Publisher.setColumns(10);
		
		txt_Price = new JTextField();
		txt_Price.setBounds(148, 139, 130, 26);
		frame.getContentPane().add(txt_Price);
		txt_Price.setColumns(10);
		
		 JButton btnUpdate = new JButton("Update Record");
	        btnUpdate.addMouseListener(new MouseAdapter() {
	        	@Override
	        	public void mouseClicked(MouseEvent e) {
	        		
	        		ac.updateRecord(txtBookId.getText(), txt_BookName.getText(), txtAuthorName.getText(), txt_category.getText(), txt_Publisher.getText(),Integer.valueOf(txt_Price.getText()));
	        	}
	        });
	        btnUpdate.setBounds(290, 49, 216, 29);
	        frame.getContentPane().add(btnUpdate);
		
		JButton btnInsertRecord = new JButton("Insert Record");
		btnInsertRecord.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				
				ac.insertRecord(txtBookId.getText(), txt_BookName.getText(), txtAuthorName.getText(), txt_category.getText(), txt_Publisher.getText(),Integer.valueOf(txt_Price.getText()));
				
			}
		});
		btnInsertRecord.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnInsertRecord.setBounds(290, 18, 216, 29);
		frame.getContentPane().add(btnInsertRecord);
		
		JButton btn_searchRecord = new JButton("Search Record");
		btn_searchRecord.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(!txt_BookName.getText().equalsIgnoreCase("")) {
					ac.displayRecordByBookName(txt_BookName.getText());
				}else if(!txtBookId.getText().equalsIgnoreCase("")){
					ac.displayRecordByBookID(txtBookId.getText());
				}else if(!txtAuthorName.getText().equalsIgnoreCase("")) {
					ac.displayRecordByAuthorName(txtAuthorName.getText());
				}else {
					ac.displayRecord();
				}
				
			}
		});
		btn_searchRecord.setBounds(290, 82, 216, 29);
		frame.getContentPane().add(btn_searchRecord);
		
		JButton btnSortByBookName = new JButton("Sort By Book Name");
		btnSortByBookName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ac.sortByBookName();
			}
		});
		btnSortByBookName.setBounds(290, 110, 216, 29);
		frame.getContentPane().add(btnSortByBookName);
		
		JButton btnSortByAuthorName = new JButton("Sort By Author name");
		btnSortByAuthorName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ac.sortByAuthor();
			}
		});
		btnSortByAuthorName.setBounds(290, 139, 216, 29);
		frame.getContentPane().add(btnSortByAuthorName);
		
		JButton btnSortByPrice = new JButton("Sort By Price");
		btnSortByPrice.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ac.sortByprice();
			}
		});
		btnSortByPrice.setBounds(290, 166, 216, 29);
		frame.getContentPane().add(btnSortByPrice);
		
		JButton btnRest = new JButton("Reset");
		btnRest.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				txtBookId.setText("");
				txt_BookName.setText("");
				txt_category.setText("");
				txt_Price.setText("");
				txt_Publisher.setText("");
				txtAuthorName.setText("");
				textArea.setText("");
				
			}
		});
		btnRest.setBounds(290, 193, 216, 29);
		frame.getContentPane().add(btnRest);
		
		 
		ta.setBounds(379, 280, -321, 115);
		frame.getContentPane().add(ta);
		
		frame.repaint();
		frame.validate();
		 
	       // textArea.setBounds(43, 261, 344, 134);
	      //  frame.getContentPane().add(textArea);
	        
	        
	        
        //JScrollPane scrollPane = new JScrollPane();
        //scrollPane.setBounds(43, 261, 344, 134);
        //frame.getContentPane().add(scrollPane);
        textArea = new JTextArea();
       
        TextAreaOutputStream taos = new TextAreaOutputStream( textArea );
        textArea.setEditable(false);
        
        
        frame.revalidate();
        frame.repaint();
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
        scrollPane.setBounds(43, 261, 344, 134);
        frame.getContentPane().add(scrollPane);
        scrollPane.setViewportView(textArea);
       
        
      
        PrintStream ps = new PrintStream( taos );
        System.setOut( ps );
        System.setErr( ps );
        frame.revalidate();
        frame.repaint();
		
	}
}
